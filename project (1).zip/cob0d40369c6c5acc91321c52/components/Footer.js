import React from "react";
const Footer=()=>{
    return <footer>
    <button><i className="fa-brands fa-twitter" ></i></button>
    <button><i className="fa-brands fa-facebook-f"></i></button>
    <button><i className="fa-brands fa-instagram"></i></button>
    <button><i className="fa-brands fa-github"></i></button>
    </footer>
    
}
export default Footer;