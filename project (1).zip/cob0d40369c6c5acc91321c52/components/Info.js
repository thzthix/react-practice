import React from "react";
const Info=()=>{
    return <div className="info">
    <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80"/>
    <h1>Laura Smith</h1>
    <h3>Frontend Developer</h3>
    <a href="#">laurasmith.website</a>
    <div className="btn-container">
    <button className="email-btn"><i className="fa-solid fa-envelope"></i>Email</button>
    <button className="linkedin-btn"><i className="fa-brands fa-linkedin"></i>LinkedIn</button>
    </div>
    </div>
    
}
export default Info;