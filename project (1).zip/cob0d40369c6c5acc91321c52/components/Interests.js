import React from "react";
const Interests=()=>{
    return <div className="interests">
    <h2>Interests</h2><p>Food expert. Music scholar. Reader. Internet fanatic. Bacon buff. Entrepreneur. Travel geek. Pop culture ninja. Coffee fanatic.</p></div>
    
}
export default Interests;