import React from "react";
import Header from "./Header";
import data from "./data";
import Card from "./Card";
const App=()=>{
    
    const items=data.map((item)=><Card key={item.id} item={item}/>);
    
    
    return <div><Header/><div className="cards--container">{items}</div></div>;
}
export default App;