import React from "react";
const Card=(props)=>{
    return <div className="card">
    <img src={props.item.imageUrl}/>
  
 <div className="div--details">
    <div className="div--location">
    <i className="fa-solid fa-location-dot"></i>
    <h3>{props.item.location}</h3>
    <a href={props.item.googleMapUrl}>View on Google Maps</a>
    
    </div>
      <h2 className="card--title">{props.item.title}</h2>
      <h4 className="card--date">{props.item.startDate} - {props.item.endDate}</h4>
      <p className="card--description">{props.item.description}</p>
     
    </div></div>
    
    
}
export default Card;